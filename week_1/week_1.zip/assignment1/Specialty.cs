﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment1
{
    enum Specialty
    {
        Java,
        Csharp,
        HTML,
        PHP,
        Unknown
    }
}
